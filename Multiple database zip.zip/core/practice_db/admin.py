from django.contrib import admin
from .models import Practice
# Register your models here.

admin.site.register(Practice)
